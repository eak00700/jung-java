package day17;

import java.util.Scanner;

//연습Ex1703. Circle 클래스.
//(실행결과의 예)
//	원의 반지름을 입력 : 5 (엔터)
//	반지름이 5인 원의 넓이는 _________ 입니다.
//- Circle 클래스.
//r (정수)   // 반지름
//area()	   // 원의 넓이를 리턴. "원의 넓이 = 3.14 * r * r"
//					     Math.PI * r * r
class Circle {
	int r;
	double area() {
		return Math.PI * r * r;
	}
}
public class Ex1703 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Circle c = new Circle();
		System.out.print("원의 반지름을 입력 : ");
		c.r = sc.nextInt();
		System.out.println("반지름이 "+c.r+"인 원의 넓이는 "+c.area()+" 입니다.");
	}
}







