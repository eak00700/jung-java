package day17;

import java.util.Scanner;

//연습Ex1701. 
//(실행결과의 예)
//	점#1의 x 입력 : 1 (엔터)
//	점#1의 y 입력 : 1 (엔터)
//	점#2의 x 입력 : 5 (엔터)
//	점#2의 y 입력 : 4 (엔터)
//	-> 두 점 사이의 거리는 5.0 입니다.
//	-> 점#1(1,1) ~ 점#2(5,4) 거리 = 5.0    // (고급화)
class Point {
	int x, y;
	double dist(int x2, int y2) {
		// (x,y) ~ (x2,y2) 까지의 거리를 리턴.
		return Math.sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2));
	}
	double dist(Point p) {
		// (x,y) ~ (p.x, p.y)
		int dx = x - p.x;
		int dy = y - p.y;
		return Math.sqrt(dx*dx + dy*dy);
	}
}

public class Ex1701 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Point p1 = new Point();
		Point p2 = new Point();
		System.out.print("점#1의 x 입력 : ");
		p1.x = sc.nextInt();
		System.out.print("점#1의 y 입력 : ");
		p1.y = sc.nextInt();
		System.out.print("점#2의 x 입력 : ");
		p2.x = sc.nextInt();
		System.out.print("점#2의 y 입력 : ");
		p2.y = sc.nextInt();
		
		System.out.println("두 점 사이의 거리는 "+p1.dist(p2.x, p2.y)+" 입니다.");
		System.out.println("두 점 사이의 거리는 "+p2.dist(p1.x, p1.y)+" 입니다.");
		
		System.out.println(p1.dist(p2));  // 이해.
		System.out.println(p2.dist(p1));  // 이해.
	}
}











